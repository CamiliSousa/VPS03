function somar() {
    let n1 = Number(window.prompt('Digite um número'))
    let n2 = Number(window.prompt('Digite outro número'))

    let res = document.querySelector('section#res')
    res.innerHTML = `<span>A soma entre ${n1} e ${n2} é igual a a ${n1 + n2}</span>`
}

function subtracao() {
    let n3 = Number(window.prompt('Digite um número'))
    let n4 = Number(window.prompt('Digite outro número'))

    let res_menos = document.querySelector('section#res_menos')
    res_menos.innerHTML = `<span>A subtração entre ${n3} e ${n4} é igual a a ${n3 - n4}</span>`
}

function divisao() {
    let n5 = Number(window.prompt('Digite um número'))
    let n6 = Number(window.prompt('Digite outro número'))

    let res_divide = document.querySelector('section#res_divide')
    res_divide.innerHTML = `<span>A divisão entre ${n5} e ${n6} é igual a a ${n5 / n6}</span>`
}

function multiplicacao() {
    let n7 = Number(window.prompt('Digite um número'))
    let n8 = Number(window.prompt('Digite outro número'))

    let res_multi = document.querySelector('section#res_multi')
    res_multi.innerHTML = `<span>A multiplicação entre ${n7} e ${n8} é igual a a ${n7 * n8}</span>`
}

function media() {
    let nome = window.prompt("Qual o seu nome?")
    let n9 = Number(window.prompt('Digite a primeira nota:'))
    let n10 = Number(window.prompt('Digite a segunda nota:'))

    med = (n9 + n10) / 2

    let msg
    if (med >= 5) {
        msg = 'Aprovado, meus parabéns!'
    }
    else {
        msg = 'Reprovado'
    }

    let res = document.getElementById('situacao')
    res.innerHTML = `Olá ${nome}! Sua média foi ${med}!`
    res.innerHTML = `<p> A mensagem que temos é: <h1 style="color:red"> ${msg} </h1></style>`

}